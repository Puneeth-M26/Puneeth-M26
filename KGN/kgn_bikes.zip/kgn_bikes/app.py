import os
import random
import string
import datetime as dt
from typing import Optional

from flask import (
    Flask, render_template, request, redirect, url_for,
    session, flash, send_from_directory
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename
from jinja2 import DictLoader

# -----------------------------
# Config
# -----------------------------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24))
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE_DIR, 'kgn_bikes.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = UPLOAD_DIR
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024  # 8MB

db = SQLAlchemy(app)

OWNER_USERNAME = os.environ.get('OWNER_USERNAME', 'kgnowner')
OWNER_PASSWORD = os.environ.get('OWNER_PASSWORD', 'kgn123')

# -----------------------------
# Templates (DictLoader)
# -----------------------------
TEMPLATES = {
  "base.html": "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\" />\n<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0\"/>\n<title>{{ title or \"KGN Bikes\" }}</title>\n<link rel=\"icon\" href=\"{{ url_for('static', filename='images/KGN.png') }}\" />\n<link href=\"https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap\" rel=\"stylesheet\">\n<style>\n:root { --brand:#232f3e; --accent:#28a745; --warn:#b12704; --link:#007185; }\n*{box-sizing:border-box}\nbody{font-family:'Montserrat',Arial,sans-serif;background:#f6f6f6;margin:0}\n.navbar{background:var(--brand);color:#fff;padding:1rem 2rem;display:flex;align-items:center;justify-content:space-between}\n.navbar a{color:#fff;text-decoration:none}\n.brand{display:flex;gap:.6rem;align-items:center;font-weight:700;letter-spacing:1px}\n.brand img{height:28px}\n.nav-actions{display:flex;gap:1rem;align-items:center}\n.container{max-width:1100px;margin:1.2rem auto;padding:0 1rem}\n.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:1rem}\n.card{background:#fff;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,.06);padding:1rem}\n.card img{width:100%;height:160px;object-fit:cover;border-radius:8px;margin-bottom:.6rem}\n.title{font-weight:700;color:var(--brand);margin:.3rem 0}\n.price{color:var(--warn);font-weight:700}\n.btn{border:none;border-radius:6px;padding:.6rem .9rem;font-weight:700;cursor:pointer}\n.btn-primary{background:var(--accent);color:#fff}\n.btn-light{background:#febd69;color:#232f3e}\n.btn-ghost{background:#fff;border:1px solid var(--warn);color:var(--warn)}\n.btn-link{background:transparent;color:#fff;cursor:pointer}\n.badge{background:#e53935;color:#fff;border-radius:999px;padding:.2rem .5rem;font-size:.8rem}\n.flash{padding:.8rem 1rem;border-radius:6px;margin:.5rem 0}\n.flash-success{background:#e6f4ea}\n.flash-error{background:#fdecea}\n.flash-info{background:#e8f0fe}\n.table{width:100%;border-collapse:collapse}\n.table th,.table td{padding:.6rem;border-bottom:1px solid #eee;text-align:left}\n.footer{background:var(--brand);color:#fff;text-align:center;padding:.9rem;margin-top:2rem}\ninput,textarea,select{width:100%;padding:.6rem;border:1px solid #ddd;border-radius:6px}\nlabel{font-size:.9rem;color:#555;margin:.35rem 0 .2rem;display:block}\n.row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}\n@media (max-width:700px){.row{grid-template-columns:1fr}}\n</style>\n</head>\n<body>\n<div class=\"navbar\">\n  <div class=\"brand\">\n    <a href=\"{{ url_for('all_bikes') }}\" style=\"display:flex;align-items:center;gap:.6rem;\">\n      <img src=\"{{ url_for('static', filename='images/KGN.png') }}\" alt=\"KGN Bikes Logo\"> KGN Bikes\n    </a>\n  </div>\n  <div class=\"nav-actions\">\n    <a href=\"{{ url_for('all_bikes') }}\">All Bikes</a>\n    <a href=\"{{ url_for('buy_bikes') }}\">Buy</a>\n    <a href=\"{{ url_for('cart') }}\">Cart</a>\n    <a href=\"{{ url_for('wishlist') }}\">Wishlist</a>\n    {% if session.get('buyer_id') %}\n      <a href=\"{{ url_for('profile') }}\">Profile</a>\n      <form action=\"{{ url_for('logout') }}\" method=\"post\" style=\"display:inline;\">\n        <button class=\"btn-link\" title=\"Logout\">Logout</button>\n      </form>\n    {% else %}\n      <a href=\"{{ url_for('buyer_login') }}\">Buyer Login</a>\n    {% endif %}\n    <a href=\"{{ url_for('owner_login') }}\">Owner</a>\n  </div>\n</div>\n<div class=\"container\">\n  {% with messages = get_flashed_messages(with_categories=true) %}\n    {% if messages %}\n      {% for cat,msg in messages %}\n        <div class=\"flash flash-{{cat}}\">{{ msg }}</div>\n      {% endfor %}\n    {% endif %}\n  {% endwith %}\n  {% block content %}{% endblock %}\n</div>\n<div class=\"footer\">&copy; 2025 KGN Bikes. All rights reserved.</div>\n</body>\n</html>",
  "owner_login.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">Owner Login</h2>\n<form method=\"post\" class=\"card\" style=\"max-width:460px\">\n  <label>Username</label><input name=\"username\" required />\n  <label>Password</label><input type=\"password\" name=\"password\" required />\n  <button class=\"btn btn-primary\" style=\"margin-top:.6rem;\">Login</button>\n</form>\n{% endblock %}",
  "owner_portal.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">Owner Portal</h2>\n<form method=\"post\" enctype=\"multipart/form-data\" class=\"card\">\n  <div class=\"row\">\n    <div>\n      <label>Bike Name</label><input name=\"name\" required>\n      <label>Model</label><input name=\"model\" required>\n      <label>Price (₹)</label><input name=\"price\" type=\"number\" min=\"0\" required>\n      <label>Year</label><input name=\"year\">\n      <label>Mileage (km)</label><input name=\"mileage\">\n    </div>\n    <div>\n      <label>Description</label><textarea name=\"description\" rows=\"6\"></textarea>\n      <label>Contact</label><input name=\"contact\" placeholder=\"+91-...\">\n      <label>Image</label><input type=\"file\" name=\"image\" accept=\"image/*\">\n      <button class=\"btn btn-primary\" style=\"margin-top:.6rem;\">Add Bike</button>\n    </div>\n  </div>\n</form>\n\n<h3 class=\"title\">Your Bikes</h3>\n<div class=\"grid\">\n  {% for b in bikes %}\n  <div class=\"card\">\n    <img src=\"{{ url_for('static', filename=b.image) if b.image else 'https://images.unsplash.com/photo-1518655048521-f130df041f66?auto=format&fit=crop&w=400&q=80' }}\" alt=\"Bike\">\n    <div class=\"title\">{{ b.name }}</div>\n    <div class=\"price\">₹{{ b.price }}</div>\n    <div>Model: {{ b.model }} | Year: {{ b.year }} | Mileage: {{ b.mileage }}</div>\n    <div style=\"margin-top:.4rem\">{{ b.description }}</div>\n    <div style=\"margin:.4rem 0;color:#007185;\">Contact: {{ b.contact }}</div>\n    <a class=\"btn btn-ghost\" href=\"{{ url_for('delete_bike', bike_id=b.id) }}\">Delete</a>\n  </div>\n  {% else %}\n  <p>No bikes yet.</p>\n  {% endfor %}\n</div>\n{% endblock %}",
  "buyer_login.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">Buyer Login (OTP Demo)</h2>\n<form method=\"post\" class=\"card\" style=\"max-width:520px\">\n  <label>Phone</label>\n  <input name=\"phone\" value=\"{{ phone or '' }}\" required>\n  {% if otp_sent %}\n    <label>Enter OTP (demo)</label>\n    <input name=\"otp_input\" value=\"\" required>\n    <div style=\"margin:.5rem 0;color:#007185\">Demo OTP: <b>{{ otp }}</b></div>\n  {% endif %}\n  <button class=\"btn btn-primary\" style=\"margin-top:.6rem;\">{{ 'Verify & Login' if otp_sent else 'Send OTP' }}</button>\n</form>\n{% endblock %}",
  "all_bikes.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">All Bikes</h2>\n<div class=\"grid\">\n  {% for b in bikes %}\n  <div class=\"card\">\n    <img src=\"{{ url_for('static', filename=b.image) if b.image else 'https://images.unsplash.com/photo-1518655048521-f130df041f66?auto=format&fit=crop&w=400&q=80' }}\" alt=\"Bike\">\n    <div class=\"title\">{{ b.name }}</div>\n    <div class=\"price\">₹{{ b.price }}</div>\n    <div>Model: {{ b.model }} | Year: {{ b.year }} | Mileage: {{ b.mileage }}</div>\n    <div style=\"margin-top:.4rem\">{{ b.description }}</div>\n    <div style=\"margin:.4rem 0;color:#007185;\">Contact: {{ b.contact }}</div>\n  </div>\n  {% else %}\n  <p>No bikes available.</p>\n  {% endfor %}\n</div>\n{% endblock %}",
  "buy_bikes.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">Buy Bikes</h2>\n<div class=\"grid\">\n  {% for b in bikes %}\n  <div class=\"card\">\n    <img src=\"{{ url_for('static', filename=b.image) if b.image else 'https://images.unsplash.com/photo-1518655048521-f130df041f66?auto=format&fit=crop&w=400&q=80' }}\" alt=\"Bike\">\n    <div class=\"title\">{{ b.name }}</div>\n    <div class=\"price\">₹{{ b.price }}</div>\n    <div>Model: {{ b.model }} | Year: {{ b.year }} | Mileage: {{ b.mileage }}</div>\n    <form method=\"post\" action=\"{{ url_for('add_to_cart', bike_id=b.id) }}\" style=\"margin-top:.6rem;display:flex;gap:.5rem;flex-wrap:wrap\">\n      <button class=\"btn btn-primary\">Add to Cart</button>\n    </form>\n    <form method=\"post\" action=\"{{ url_for('add_to_wishlist', bike_id=b.id) }}\" style=\"display:inline;\">\n      <button class=\"btn btn-light\" type=\"submit\">Add to Wishlist</button>\n    </form>\n  </div>\n  {% else %}\n  <p>No bikes available.</p>\n  {% endfor %}\n</div>\n{% endblock %}",
  "cart.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">Your Cart</h2>\n{% if not items %}\n<p>No items in cart.</p>\n{% else %}\n<table class=\"table\">\n  <thead><tr><th>Bike</th><th>Model</th><th>Price</th><th></th></tr></thead>\n  <tbody>\n  {% for it in items %}\n    <tr>\n      <td>{{ it.bike.name }}</td>\n      <td>{{ it.bike.model }}</td>\n      <td>₹{{ it.bike.price }}</td>\n      <td><a class=\"btn btn-ghost\" href=\"{{ url_for('remove_from_cart', item_id=it.id) }}\">Remove</a></td>\n    </tr>\n  {% endfor %}\n  </tbody>\n</table>\n<h3>Total: ₹{{ total }}</h3>\n{% endif %}\n{% endblock %}",
  "wishlist.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">Wishlist</h2>\n{% if not items %}\n<p>No items in wishlist.</p>\n{% else %}\n<table class=\"table\">\n  <thead><tr><th>Bike</th><th>Model</th><th>Price</th><th>Actions</th></tr></thead>\n  <tbody>\n  {% for it in items %}\n    <tr>\n      <td>{{ it.bike.name }}</td>\n      <td>{{ it.bike.model }}</td>\n      <td>₹{{ it.bike.price }}</td>\n      <td>\n        <a class=\"btn btn-primary\" href=\"{{ url_for('move_wishlist_to_cart', item_id=it.id) }}\">Move to Cart</a>\n        <a class=\"btn btn-ghost\" href=\"{{ url_for('remove_from_wishlist', item_id=it.id) }}\">Remove</a>\n      </td>\n    </tr>\n  {% endfor %}\n  </tbody>\n</table>\n{% endif %}\n{% endblock %}",
  "profile.html": "{% extends \"base.html\" %}{% block content %}\n<h2 class=\"title\">Profile</h2>\n<form method=\"post\" class=\"card\" style=\"max-width:560px\">\n  <label>Name</label><input name=\"name\" value=\"{{ buyer.name or '' }}\">\n  <label>Email</label><input type=\"email\" name=\"email\" value=\"{{ buyer.email or '' }}\">\n  <label>Address</label><textarea name=\"address\" rows=\"3\">{{ buyer.address or '' }}</textarea>\n  <button class=\"btn btn-primary\" style=\"margin-top:.6rem;\">Save</button>\n</form>\n{% endblock %}"
}

app.jinja_loader = DictLoader(TEMPLATES)

# -----------------------------
# Models
# -----------------------------
class Bike(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    model = db.Column(db.String(80), nullable=False)
    price = db.Column(db.Integer, nullable=False)
    year = db.Column(db.String(10))
    mileage = db.Column(db.String(20))
    description = db.Column(db.Text)
    contact = db.Column(db.String(60))
    image = db.Column(db.String(200))  # relative path under static/uploads

class Buyer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), unique=True, index=True, nullable=False)
    name = db.Column(db.String(80))
    email = db.Column(db.String(120))
    address = db.Column(db.Text)

class OTP(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), index=True, nullable=False)
    code = db.Column(db.String(6), nullable=False)
    expires_at = db.Column(db.DateTime, nullable=False)

class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('buyer.id'), nullable=False)
    bike_id = db.Column(db.Integer, db.ForeignKey('bike.id'), nullable=False)
    buyer = db.relationship('Buyer', backref=db.backref('cart_items', lazy=True))
    bike = db.relationship('Bike')

class WishlistItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    buyer_id = db.Column(db.Integer, db.ForeignKey('buyer.id'), nullable=False)
    bike_id = db.Column(db.Integer, db.ForeignKey('bike.id'), nullable=False)
    buyer = db.relationship('Buyer', backref=db.backref('wishlist_items', lazy=True))
    bike = db.relationship('Bike')

with app.app_context():
    db.create_all()

# -----------------------------
# Helpers
# -----------------------------
def current_buyer() -> Optional[Buyer]:
    bid = session.get('buyer_id')
    if not bid:
        return None
    return Buyer.query.get(bid)

def save_image(file) -> Optional[str]:
    if not file or file.filename == '':
        return None
    filename = secure_filename(file.filename)
    # make unique
    root, ext = os.path.splitext(filename)
    rand = ''.join(random.choices(string.ascii_letters + string.digits, k=6))
    filename = f"{root}_{rand}{ext}"
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(path)
    return f"uploads/{filename}"  # relative to static/

def clean_expired_otps():
    now = dt.datetime.utcnow()
    OTP.query.filter(OTP.expires_at < now).delete()
    db.session.commit()

# -----------------------------
# Routes
# -----------------------------
@app.route("/")
def home():
    return redirect(url_for('all_bikes'))

# --- Owner ---
@app.route("/owner-login", methods=["GET", "POST"])
def owner_login():
    error = ''
    if request.method == "POST":
        if request.form.get('username') == OWNER_USERNAME and request.form.get('password') == OWNER_PASSWORD:
            session['owner'] = True
            return redirect(url_for('owner_portal'))
        else:
            error = 'Invalid username or password.'
            flash(error, 'error')
    return render_template("owner_login.html", title="Owner Login")

@app.route("/owner-portal", methods=["GET", "POST"])
def owner_portal():
    if not session.get('owner'):
        return redirect(url_for('owner_login'))

    if request.method == "POST":
        name = request.form.get('name','').strip()
        model = request.form.get('model','').strip()
        price = request.form.get('price','0').strip()
        year = request.form.get('year','').strip()
        mileage = request.form.get('mileage','').strip()
        description = request.form.get('description','').strip()
        contact = request.form.get('contact','').strip()
        imgfile = request.files.get('image')

        if not name or not model or not price:
            flash("Name, Model, and Price are required.", "error")
        else:
            image_path = save_image(imgfile)
            try:
                price_int = int(price)
            except ValueError:
                price_int = 0
            bike = Bike(
                name=name, model=model, price=price_int, year=year,
                mileage=mileage, description=description, contact=contact,
                image=image_path
            )
            db.session.add(bike)
            db.session.commit()
            flash("Bike added successfully!", "success")

    bikes = Bike.query.order_by(Bike.id.desc()).all()
    return render_template("owner_portal.html", title="Owner Portal", bikes=bikes)

@app.route("/delete-bike/<int:bike_id>")
def delete_bike(bike_id:int):
    if not session.get('owner'):
        return redirect(url_for('owner_login'))
    b = Bike.query.get_or_404(bike_id)
    # delete image file if present
    if b.image:
        abs_path = os.path.join(app.static_folder, b.image)
        if os.path.isfile(abs_path):
            try:
                os.remove(abs_path)
            except Exception:
                pass
    db.session.delete(b)
    db.session.commit()
    flash("Bike deleted.", "success")
    return redirect(url_for('owner_portal'))

# --- Public & buyer views ---
@app.route("/all-bikes")
def all_bikes():
    bikes = Bike.query.order_by(Bike.id.desc()).all()
    return render_template("all_bikes.html", title="All Bikes", bikes=bikes)

@app.route("/buy-bikes")
def buy_bikes():
    bikes = Bike.query.order_by(Bike.id.desc()).all()
    return render_template("buy_bikes.html", title="Buy Bikes", bikes=bikes)

# --- Buyer auth (OTP demo) ---
@app.route("/buyer-login", methods=["GET","POST"])
def buyer_login():
    clean_expired_otps()
    otp_sent = False
    otp = None
    phone = None

    if request.method == "POST":
        # Step 2: Verify
        if request.form.get("otp_input") is not None:
            phone = request.form.get("phone","").strip()
            code = request.form.get("otp_input","").strip()
            now = dt.datetime.utcnow()
            record = OTP.query.filter_by(phone=phone, code=code).filter(OTP.expires_at > now).first()
            if record:
                # get or create buyer
                buyer = Buyer.query.filter_by(phone=phone).first()
                if not buyer:
                    buyer = Buyer(phone=phone)
                    db.session.add(buyer)
                    db.session.commit()
                session['buyer_id'] = buyer.id
                # cleanup this OTP
                db.session.delete(record)
                db.session.commit()
                flash("Logged in successfully.", "success")
                return redirect(url_for('buy_bikes'))
            else:
                flash("Invalid or expired OTP.", "error")
                # Show again with a fresh otp for demo
                phone = request.form.get("phone","").strip()
                otp = str(random.randint(1000,9999))
                db.session.add(OTP(phone=phone, code=otp, expires_at=dt.datetime.utcnow()+dt.timedelta(minutes=5)))
                db.session.commit()
                otp_sent = True
        # Step 1: Send
        else:
            phone = request.form.get("phone","").strip()
            if not phone:
                flash("Please enter phone number.", "error")
            else:
                otp = str(random.randint(1000,9999))
                db.session.add(OTP(phone=phone, code=otp, expires_at=dt.datetime.utcnow()+dt.timedelta(minutes=5)))
                db.session.commit()
                otp_sent = True
                flash("OTP generated (demo).", "info")

    return render_template("buyer_login.html", title="Buyer Login", otp_sent=otp_sent, otp=otp, phone=phone)

@app.post("/logout")
def logout():
    session.pop('owner', None)
    session.pop('buyer_id', None)
    flash('Logged out.', 'info')
    return redirect(url_for('all_bikes'))

# --- Profile ---
@app.route("/profile", methods=["GET","POST"])
def profile():
    bid = session.get('buyer_id')
    if not bid:
        return redirect(url_for('buyer_login'))
    buyer = Buyer.query.get(bid)
    if request.method == "POST":
        buyer.name = request.form.get('name','').strip()
        buyer.email = request.form.get('email','').strip()
        buyer.address = request.form.get('address','').strip()
        db.session.commit()
        flash("Profile updated!", "success")
        return redirect(url_for('profile'))
    return render_template("profile.html", title="Profile", buyer=buyer)

# --- Cart / Wishlist ---
@app.post("/add-to-cart/<int:bike_id>")
def add_to_cart(bike_id:int):
    bid = session.get('buyer_id')
    if not bid:
        return redirect(url_for('buyer_login'))
    exists = CartItem.query.filter_by(buyer_id=bid, bike_id=bike_id).first()
    if not exists:
        db.session.add(CartItem(buyer_id=bid, bike_id=bike_id))
        db.session.commit()
        flash("Added to cart.", "success")
    else:
        flash("Already in cart.", "info")
    return redirect(url_for('buy_bikes'))

@app.get("/remove-from-cart/<int:item_id>")
def remove_from_cart(item_id:int):
    bid = session.get('buyer_id')
    if not bid:
        return redirect(url_for('buyer_login'))
    it = CartItem.query.get_or_404(item_id)
    if it.buyer_id != bid:
        flash("Not allowed.", "error")
        return redirect(url_for('cart'))
    db.session.delete(it)
    db.session.commit()
    flash("Removed from cart.", "success")
    return redirect(url_for('cart'))

@app.get("/cart")
def cart():
    bid = session.get('buyer_id')
    items = []
    total = 0
    if bid:
        items = CartItem.query.filter_by(buyer_id=bid).all()
        total = sum(i.bike.price for i in items)
    return render_template("cart.html", title="Cart", items=items, total=total)

@app.post("/add-to-wishlist/<int:bike_id>")
def add_to_wishlist(bike_id:int):
    bid = session.get('buyer_id')
    if not bid:
        return redirect(url_for('buyer_login'))
    exists = WishlistItem.query.filter_by(buyer_id=bid, bike_id=bike_id).first()
    if not exists:
        db.session.add(WishlistItem(buyer_id=bid, bike_id=bike_id))
        db.session.commit()
        flash("Added to wishlist.", "success")
    else:
        flash("Already in wishlist.", "info")
    return redirect(url_for('buy_bikes'))

@app.get("/remove-from-wishlist/<int:item_id>")
def remove_from_wishlist(item_id:int):
    bid = session.get('buyer_id')
    if not bid:
        return redirect(url_for('buyer_login'))
    it = WishlistItem.query.get_or_404(item_id)
    if it.buyer_id != bid:
        flash("Not allowed.", "error")
        return redirect(url_for('wishlist'))
    db.session.delete(it)
    db.session.commit()
    flash("Removed from wishlist.", "success")
    return redirect(url_for('wishlist'))

@app.get("/move-wishlist-to-cart/<int:item_id>")
def move_wishlist_to_cart(item_id:int):
    bid = session.get('buyer_id')
    if not bid:
        return redirect(url_for('buyer_login'))
    it = WishlistItem.query.get_or_404(item_id)
    if it.buyer_id != bid:
        flash("Not allowed.", "error")
        return redirect(url_for('wishlist'))
    # move
    exists = CartItem.query.filter_by(buyer_id=bid, bike_id=it.bike_id).first()
    if not exists:
        db.session.add(CartItem(buyer_id=bid, bike_id=it.bike_id))
    db.session.delete(it)
    db.session.commit()
    flash("Moved to cart.", "success")
    return redirect(url_for('cart'))

@app.get("/wishlist")
def wishlist():
    bid = session.get('buyer_id')
    items = []
    if bid:
        items = WishlistItem.query.filter_by(buyer_id=bid).all()
    return render_template("wishlist.html", title="Wishlist", items=items)

# Static helper (serving uploaded files safely handled by Flask static)
@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# -----------------------------
# Run
# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)
